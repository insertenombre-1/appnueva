<script>
    import Navbar from '$lib/components/navbar.svelte';
    import Footer from '$lib/components/footer.svelte';
    import Loading from '$lib/components/Loading.svelte';
    import FormField from '$lib/components/FormField.svelte';

    const API = 'http://127.0.0.1:8000';

    let eventos = $state([]);
    let semilleros = $state([]);
    let cargando = $state(true);
    let guardando = $state(false);
    let eliminando = $state(false);

    let error = $state('');
    let mensajeExito = $state('');

    let mostrarFormulario = $state(false);
    let modoEdicion = $state(false);
    let idEventoEditar = $state(null);

    let eventoSeleccionado = $state(null);
    let eventoPorEliminar = $state(null);

    let nuevoEvento = $state({
        id_semillero: '',
        fecha: '',
        hora_inicio: '',
        hora_fin: '',
        tema: '',
        descripcion: ''
    });

    function limpiarMensajes() {
        error = '';
        mensajeExito = '';
    }

    async function cargarEventos() {
        cargando = true;

        try {
            const respuesta = await fetch(`${API}/reuniones/`);

            if (!respuesta.ok) {
                throw new Error('No se pudieron cargar los eventos.');
            }

            eventos = await respuesta.json();
        } catch (e) {
            error = e.message || 'No fue posible conectar con la API.';
        } finally {
            cargando = false;
        }
    }

    async function cargarSemilleros() {
        try {
            const respuesta = await fetch(`${API}/semilleros/`);

            if (!respuesta.ok) {
                throw new Error('No se pudieron cargar los semilleros.');
            }

            const datos = await respuesta.json();

            semilleros = datos.filter(s => s.estado === true);
        } catch (e) {
            error = e.message || 'No fue posible cargar los semilleros.';
        }
    }

    function abrirFormulario() {
        nuevoEvento = {
            id_semillero: '',
            fecha: '',
            hora_inicio: '',
            hora_fin: '',
            tema: '',
            descripcion: ''
        };

        modoEdicion = false;
        idEventoEditar = null;
        limpiarMensajes();
        mostrarFormulario = true;
    }

    function editarEvento(evento) {
        nuevoEvento = {
            id_semillero: String(evento.id_semillero),
            fecha: evento.fecha,
            hora_inicio: evento.hora_inicio?.slice(0, 5) || '',
            hora_fin: evento.hora_fin?.slice(0, 5) || '',
            tema: evento.tema || '',
            descripcion: evento.descripcion || ''
        };

        idEventoEditar = evento.id_reunion;
        modoEdicion = true;
        eventoSeleccionado = null;

        limpiarMensajes();
        mostrarFormulario = true;
    }

    async function guardarEvento(e) {
        e.preventDefault();

        if (guardando) return;

        limpiarMensajes();

        const tema = nuevoEvento.tema.trim();

        if (!tema) {
            error = 'Escribe el tema del evento.';
            return;
        }

        if (
            nuevoEvento.hora_fin &&
            nuevoEvento.hora_fin <= nuevoEvento.hora_inicio
        ) {
            error = 'La hora de finalización debe ser posterior a la hora de inicio.';
            return;
        }

        guardando = true;

        try {
            const eventoExistente = eventos.find(
                r => r.id_reunion === idEventoEditar
            );

            const datosEvento = {
                id_semillero: Number(nuevoEvento.id_semillero),
                fecha: nuevoEvento.fecha,
                hora_inicio: nuevoEvento.hora_inicio,
                hora_fin: nuevoEvento.hora_fin || null,
                tema,
                descripcion: nuevoEvento.descripcion.trim() || null,
                estado: modoEdicion
                    ? eventoExistente?.estado ?? true
                    : true
            };

            const respuesta = await fetch(
                modoEdicion
                    ? `${API}/reuniones/${idEventoEditar}`
                    : `${API}/reuniones/`,
                {
                    method: modoEdicion ? 'PUT' : 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(datosEvento)
                }
            );

            let resultado = {};

            try {
                resultado = await respuesta.json();
            } catch {
                // Algunas respuestas de la API no tienen contenido JSON.
            }

            if (!respuesta.ok) {
                throw new Error(
                    resultado.detail ||
                    'No se pudo guardar el evento. Revisa los datos.'
                );
            }

            const mensaje = modoEdicion
                ? 'El evento se actualizó correctamente.'
                : 'El evento se creó correctamente.';

            mostrarFormulario = false;
            modoEdicion = false;
            idEventoEditar = null;

            await cargarEventos();

            if (!error) {
                mensajeExito = mensaje;
            }
        } catch (e) {
            error = e.message || 'Ocurrió un error al guardar el evento.';
        } finally {
            guardando = false;
        }
    }

    function solicitarEliminar(evento) {
        eventoPorEliminar = evento;
        eventoSeleccionado = null;
        limpiarMensajes();
    }

    async function eliminarEvento() {
        if (!eventoPorEliminar || eliminando) return;

        eliminando = true;
        limpiarMensajes();

        try {
            const respuesta = await fetch(
                `${API}/reuniones/${eventoPorEliminar.id_reunion}`,
                {
                    method: 'DELETE'
                }
            );

            let resultado = {};

            try {
                resultado = await respuesta.json();
            } catch {
                // La API también puede responder sin contenido JSON.
            }

            if (!respuesta.ok) {
                throw new Error(
                    resultado.detail ||
                    'No se pudo eliminar el evento.'
                );
            }

            const nombreEvento = eventoPorEliminar.tema;

            eventoPorEliminar = null;

            await cargarEventos();

            if (!error) {
                mensajeExito =
                    `El evento "${nombreEvento}" se eliminó correctamente.`;
            }
        } catch (e) {
            error = e.message || 'Ocurrió un error al eliminar el evento.';
        } finally {
            eliminando = false;
        }
    }

    function fechaCompleta(fecha) {
        if (!fecha) return 'Fecha no disponible';

        return new Date(`${fecha}T12:00:00`).toLocaleDateString(
            'es-CO',
            {
                day: '2-digit',
                month: 'long',
                year: 'numeric'
            }
        );
    }

    function nombreSemillero(id) {
        return semilleros.find(
            s => Number(s.id_semillero) === Number(id)
        )?.nombre || `Semillero ${id}`;
    }

    // Carga inicial de la información.
    cargarEventos();
    cargarSemilleros();
</script>

<Navbar />

<div class="container py-5">
    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-3">
        <div>
            <h1 class="fw-bold titulo">Eventos</h1>
            <p class="text-secondary">
                Consulta las próximas actividades de investigación.
            </p>
        </div>

        <button
            type="button"
            class="btn btn-primary"
            onclick={abrirFormulario}
        >
            <i class="bi bi-plus-lg me-2"></i>
            Nuevo evento
        </button>
    </div>

    {#if error && !mostrarFormulario && !eventoPorEliminar}
        <div class="alert alert-danger" role="alert">
            {error}
        </div>
    {/if}

    {#if mensajeExito}
        <div class="alert alert-success" role="status">
            <i class="bi bi-check-circle me-2"></i>
            {mensajeExito}
        </div>
    {/if}

    <div class="card eventos-card">
        <div class="card-body p-4">
            {#if cargando}
                <Loading mensaje="Cargando reuniones..." />

            {:else if eventos.length === 0}
                <div class="text-center py-4">
                    <i class="bi bi-calendar-x icono-vacio"></i>
                    <p class="text-secondary mt-3">
                        No hay eventos registrados todavía.
                    </p>
                    <button
                        type="button"
                        class="btn btn-primary"
                        onclick={abrirFormulario}
                    >
                        Crear primer evento
                    </button>
                </div>

            {:else}
                {#each eventos as evento (evento.id_reunion)}
                    <div class="evento">
                        <div class="fecha">
                            <strong>
                                {evento.fecha?.slice(8, 10) || '--'}
                            </strong>
                            <small>
                                {#if evento.fecha}
                                    {new Date(`${evento.fecha}T12:00:00`)
                                        .toLocaleDateString('es-CO', {
                                            month: 'short'
                                        })
                                        .replace('.', '')
                                        .toUpperCase()}
                                {:else}
                                    ---
                                {/if}
                            </small>
                        </div>

                        <div class="flex-grow-1 datos-evento">
                            <h5 class="fw-bold mb-1">
                                {evento.tema}
                            </h5>

                            <p class="text-secondary mb-1">
                                <i class="bi bi-clock me-1"></i>
                                {evento.hora_inicio?.slice(0, 5) || '--:--'}
                                <span class="mx-2">•</span>
                                {fechaCompleta(evento.fecha)}
                            </p>

                            <small class="text-secondary">
                                <i class="bi bi-people me-1"></i>
                                {nombreSemillero(evento.id_semillero)}
                            </small>

                            <div class="mt-2">
                                <span
                                    class:estado-activo={evento.estado}
                                    class:estado-finalizado={!evento.estado}
                                    class="estado"
                                >
                                    {evento.estado ? 'En curso' : 'Finalizada'}
                                </span>
                            </div>
                        </div>

                        <div class="acciones-evento">
                            <button
                                type="button"
                                class="btn btn-outline-primary"
                                onclick={() => {
                                    limpiarMensajes();
                                    eventoSeleccionado = evento;
                                }}
                            >
                                <i class="bi bi-eye me-1"></i>
                                Ver
                            </button>

                            <button
                                type="button"
                                class="btn btn-outline-secondary"
                                onclick={() => editarEvento(evento)}
                            >
                                <i class="bi bi-pencil me-1"></i>
                                Editar
                            </button>

                            <button
                                type="button"
                                class="btn btn-outline-danger"
                                onclick={() => solicitarEliminar(evento)}
                            >
                                <i class="bi bi-trash me-1"></i>
                                Eliminar
                            </button>
                        </div>
                    </div>
                {/each}
            {/if}
        </div>
    </div>
</div>

{#if mostrarFormulario}
    <div class="fondo-modal">
        <div
            class="modal-contenido"
            role="dialog"
            aria-modal="true"
            aria-labelledby="titulo-formulario"
        >
            <h4 id="titulo-formulario" class="titulo fw-bold mb-4">
                {modoEdicion ? 'Editar evento' : 'Nuevo evento'}
            </h4>

            <form onsubmit={guardarEvento}>
                <label class="form-label" for="semillero">
                    Semillero
                </label>

                <select
                    id="semillero"
                    class="form-select mb-3"
                    bind:value={nuevoEvento.id_semillero}
                    required
                >
                    <option value="">Selecciona un semillero</option>

                    {#each semilleros as s (s.id_semillero)}
                        <option value={String(s.id_semillero)}>
                            {s.nombre}
                        </option>
                    {/each}
                </select>

                {#if semilleros.length === 0}
                    <p class="text-secondary small">
                        No hay semilleros activos disponibles.
                    </p>
                {/if}

                <FormField
                    id="tema"
                    etiqueta="Tema"
                    bind:valor={nuevoEvento.tema}
                    requerido={true}
                    placeholder="Escribe el tema del evento"
                    maximoCaracteres={150}
                />

                <label class="form-label" for="fecha">
                    Fecha
                </label>
                <input
                    id="fecha"
                    type="date"
                    class="form-control mb-3"
                    bind:value={nuevoEvento.fecha}
                    required
                />

                <label class="form-label" for="inicio">
                    Hora de inicio
                </label>
                <input
                    id="inicio"
                    type="time"
                    class="form-control mb-3"
                    bind:value={nuevoEvento.hora_inicio}
                    required
                />

                <label class="form-label" for="fin">
                    Hora de finalización
                </label>
                <input
                    id="fin"
                    type="time"
                    class="form-control mb-3"
                    bind:value={nuevoEvento.hora_fin}
                />

                <label class="form-label" for="descripcion">
                    Descripción
                </label>
                <textarea
                    id="descripcion"
                    class="form-control mb-3"
                    rows="3"
                    bind:value={nuevoEvento.descripcion}
                    placeholder="Detalles adicionales del evento (opcional)"
                ></textarea>

                {#if error}
                    <div class="alert alert-danger" role="alert">
                        {error}
                    </div>
                {/if}

                <div class="d-flex justify-content-end gap-2 flex-wrap">
                    <button
                        type="button"
                        class="btn btn-outline-secondary"
                        disabled={guardando}
                        onclick={() => {
                            mostrarFormulario = false;
                            limpiarMensajes();
                        }}
                    >
                        Cancelar
                    </button>

                    <button
                        type="submit"
                        class="btn btn-primary"
                        disabled={guardando || semilleros.length === 0}
                    >
                        {#if guardando}
                            <span class="spinner-border spinner-border-sm me-2"></span>
                            Guardando...
                        {:else}
                            {modoEdicion ? 'Guardar cambios' : 'Guardar evento'}
                        {/if}
                    </button>
                </div>
            </form>
        </div>
    </div>
{/if}

{#if eventoSeleccionado}
    <div class="fondo-modal">
        <div
            class="modal-contenido"
            role="dialog"
            aria-modal="true"
            aria-labelledby="titulo-detalle"
        >
            <h4 id="titulo-detalle" class="titulo fw-bold mb-4">
                {eventoSeleccionado.tema}
            </h4>

            <p>
                <strong>Semillero:</strong>
                {nombreSemillero(eventoSeleccionado.id_semillero)}
            </p>

            <p>
                <strong>Fecha:</strong>
                {fechaCompleta(eventoSeleccionado.fecha)}
            </p>

            <p>
                <strong>Hora de inicio:</strong>
                {eventoSeleccionado.hora_inicio?.slice(0, 5) || 'No definida'}
            </p>

            <p>
                <strong>Hora de finalización:</strong>
                {eventoSeleccionado.hora_fin?.slice(0, 5) || 'No definida'}
            </p>

            <p>
                <strong>Estado:</strong>
                {eventoSeleccionado.estado ? 'En curso' : 'Finalizada'}
            </p>

            <p>
                <strong>Descripción:</strong>
                {eventoSeleccionado.descripcion || 'Sin descripción.'}
            </p>

            <div class="d-flex justify-content-end gap-2 flex-wrap">
                <button
                    type="button"
                    class="btn btn-outline-secondary"
                    onclick={() => {
                        eventoSeleccionado = null;
                    }}
                >
                    Cerrar
                </button>

                <button
                    type="button"
                    class="btn btn-primary"
                    onclick={() => editarEvento(eventoSeleccionado)}
                >
                    <i class="bi bi-pencil me-1"></i>
                    Editar evento
                </button>
            </div>
        </div>
    </div>
{/if}

{#if eventoPorEliminar}
    <div class="fondo-modal">
        <div
            class="modal-contenido modal-confirmacion"
            role="dialog"
            aria-modal="true"
            aria-labelledby="titulo-eliminar"
        >
            <div class="icono-eliminar">
                <i class="bi bi-trash"></i>
            </div>

            <h4 id="titulo-eliminar" class="titulo fw-bold mb-3">
                Confirmar eliminación
            </h4>

            <p>
                ¿Seguro que deseas eliminar el evento
                <strong>{eventoPorEliminar.tema}</strong>?
            </p>

            <p class="text-secondary">
                Esta acción no se puede deshacer.
            </p>

            {#if error}
                <div class="alert alert-danger" role="alert">
                    {error}
                </div>
            {/if}

            <div class="d-flex justify-content-end gap-2 flex-wrap">
                <button
                    type="button"
                    class="btn btn-outline-secondary"
                    disabled={eliminando}
                    onclick={() => {
                        eventoPorEliminar = null;
                        limpiarMensajes();
                    }}
                >
                    Cancelar
                </button>

                <button
                    type="button"
                    class="btn btn-danger"
                    disabled={eliminando}
                    onclick={eliminarEvento}
                >
                    {#if eliminando}
                        Eliminando...
                    {:else}
                        Sí, eliminar
                    {/if}
                </button>
            </div>
        </div>
    </div>
{/if}

<Footer />

<style>
    .titulo {
        color: #0f3460;
    }

    .eventos-card {
        border: none;
        border-radius: 18px;
        box-shadow: 0 4px 15px rgba(15, 52, 96, .08);
    }

    .evento {
        display: flex;
        align-items: center;
        gap: 20px;
        padding: 20px 5px;
        border-bottom: 1px solid #edf0f4;
    }

    .evento:last-child {
        border-bottom: none;
    }

    .fecha {
        width: 65px;
        height: 65px;
        flex-shrink: 0;
        border-radius: 12px;
        background: #eaf2fb;
        color: #0f3460;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
    }

    .fecha strong {
        font-size: 1.5rem;
    }

    .fecha small {
        font-weight: 600;
    }

    .datos-evento {
        min-width: 150px;
    }

    .acciones-evento {
        display: flex;
        align-items: center;
        gap: 8px;
        flex-wrap: wrap;
    }

    .estado {
        display: inline-block;
        padding: 4px 10px;
        border-radius: 20px;
        font-size: .8rem;
        font-weight: 600;
    }

    .estado-activo {
        color: #146c43;
        background: #d1e7dd;
    }

    .estado-finalizado {
        color: #41464b;
        background: #e2e3e5;
    }

    .icono-vacio {
        font-size: 2.5rem;
        color: #8b9bb0;
    }

    .fondo-modal {
        position: fixed;
        inset: 0;
        z-index: 1050;
        background: rgba(0, 0, 0, .45);
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 16px;
        overflow-y: auto;
    }

    .modal-contenido {
        background: white;
        width: 100%;
        max-width: 550px;
        max-height: 90vh;
        overflow-y: auto;
        border-radius: 18px;
        padding: 25px;
        box-shadow: 0 15px 45px rgba(0, 0, 0, .15);
    }

    .modal-confirmacion {
        max-width: 450px;
    }

    .icono-eliminar {
        width: 52px;
        height: 52px;
        display: flex;
        align-items: center;
        justify-content: center;
        margin-bottom: 18px;
        border-radius: 50%;
        background: #f8d7da;
        color: #b02a37;
        font-size: 1.4rem;
    }

    @media (max-width: 768px) {
        .evento {
            align-items: flex-start;
            flex-wrap: wrap;
        }

        .datos-evento {
            flex: 1;
        }

        .acciones-evento {
            width: 100%;
            padding-left: 0;
        }
    }

    @media (max-width: 480px) {
        .acciones-evento button {
            flex: 1 1 auto;
        }

        .modal-contenido {
            padding: 20px;
        }
    }
</style>
