<script>
    let {
        mensaje = 'Cargando información...'
    } = $props();
</script>

<div class="contenedor-carga" role="status" aria-live="polite">
    <span class="rueda"></span>
    <p>{mensaje}</p>
</div>

<style>
    .contenedor-carga {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        gap: 12px;
        padding: 30px 16px;
        color: #66758a;
        text-align: center;
    }

    .rueda {
        width: 32px;
        height: 32px;
        border: 4px solid #e5eef9;
        border-top-color: #0f3460;
        border-radius: 50%;
        animation: girar 0.8s linear infinite;
    }

    p {
        margin: 0;
        font-size: 14px;
    }

    @keyframes girar {
        to {
            transform: rotate(360deg);
        }
    }
</style>
