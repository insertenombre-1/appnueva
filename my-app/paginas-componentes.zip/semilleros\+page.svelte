
<script>
    import { onMount } from 'svelte';
    import Navbar from '$lib/components/navbar.svelte';
    import {
        createTable,
        FlexRender,
        tableFeatures,
        createSortedRowModel,
        rowSortingFeature,
        sortFns
    } from '@tanstack/svelte-table';
    import Confirmation from '$lib/components/Confirmation.svelte';
    import Loading from '$lib/components/Loading.svelte';
    import FormField from '$lib/components/FormField.svelte';

    const API = 'http://127.0.0.1:8000';

    let semilleros = $state([]);
    let lineas = $state([]);
    let cargando = $state(true);
    let guardando = $state(false);
    let error = $state('');
    let mensaje = $state('');
    let mostrarFormulario = $state(false);
    let editandoId = $state(null);
    let mostrarConfirmacion = $state(false);
    let semilleroSeleccionado = $state(null);

    let formulario = $state({
        nombre: '',
        descripcion: '',
        id_linea: '',
        estado: true
    });

    onMount(async () => {
        await cargarDatos();
    });

    async function cargarDatos() {
        cargando = true;
        error = '';

        try {
            const [resSemilleros, resLineas] = await Promise.all([
                fetch(`${API}/semilleros/`),
                fetch(`${API}/lineas-investigacion/`)
            ]);

            if (!resSemilleros.ok || !resLineas.ok) {
                throw new Error('No se pudieron cargar los datos.');
            }

            semilleros = await resSemilleros.json();
            lineas = await resLineas.json();
        } catch (e) {
            console.error('Error al cargar semilleros:', e);
            error = e.message || 'No se pudieron cargar los datos.';
        } finally {
            cargando = false;
            console.log('Carga terminada:', {
                cargando,
                semilleros: semilleros.length,
                lineas: lineas.length
            });
        }
    }

    function nombreLinea(id) {
        const linea = lineas.find(
            (l) => String(l.id_linea) === String(id)
        );

        return linea
            ? linea.nombre ??
                linea.nombre_linea ??
                linea.nombre_linea_investigacion ??
                'Línea de investigación'
            : 'Línea no encontrada';
    }

    function abrirNuevo() {
        editandoId = null;
        formulario = {
            nombre: '',
            descripcion: '',
            id_linea: lineas.length ? String(lineas[0].id_linea) : '',
            estado: true
        };
        mensaje = '';
        error = '';
        mostrarFormulario = true;
    }

    function abrirEdicion(s) {
        editandoId = s.id_semillero;
        formulario = {
            nombre: s.nombre ?? '',
            descripcion: s.descripcion ?? '',
            id_linea: String(s.id_linea ?? ''),
            estado: s.estado ?? true
        };
        mensaje = '';
        error = '';
        mostrarFormulario = true;
    }

    async function guardar() {
        if (!formulario.nombre.trim() || !formulario.id_linea) {
            error = 'Escribe el nombre y selecciona una línea de investigación.';
            return;
        }

        guardando = true;
        error = '';
        mensaje = '';

        const datos = {
            nombre: formulario.nombre.trim(),
            descripcion: formulario.descripcion.trim() || null,
            id_linea: Number(formulario.id_linea),
            estado: formulario.estado
        };

        try {
            const url = editandoId !== null
                ? `${API}/semilleros/${editandoId}`
                : `${API}/semilleros/`;

            const respuesta = await fetch(url, {
                method: editandoId !== null ? 'PUT' : 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(datos)
            });

            if (!respuesta.ok) {
                const detalle = await respuesta.json().catch(() => ({}));
                throw new Error(
                    detalle.detail || 'No se pudo guardar el semillero.'
                );
            }

            mostrarFormulario = false;
            mensaje = editandoId !== null
                ? 'Semillero actualizado correctamente.'
                : 'Semillero creado correctamente.';

            await cargarDatos();
        } catch (e) {
            error = e.message || 'Ocurrió un error al guardar.';
        } finally {
            guardando = false;
        }
    }

    function solicitarEliminar(s) {
        semilleroSeleccionado = s;
        mostrarConfirmacion = true;
    }

    async function eliminarConfirmado() {
        const s = semilleroSeleccionado;

        if (!s) return;

        error = '';
        mensaje = '';

        try {
            const respuesta = await fetch(
                `${API}/semilleros/${s.id_semillero}`,
                { method: 'DELETE' }
            );

            if (!respuesta.ok) {
                const detalle = await respuesta.json().catch(() => ({}));
                throw new Error(
                    detalle.detail || 'No se pudo eliminar el semillero.'
                );
            }

            mensaje = 'Semillero eliminado correctamente.';
            await cargarDatos();
        } catch (e) {
            error = e.message || 'Ocurrió un error al eliminar.';
        } finally {
            mostrarConfirmacion = false;
            semilleroSeleccionado = null;
        }
    }

    const features = tableFeatures({
        rowSortingFeature,
        sortedRowModel: createSortedRowModel(),
        sortFns
    });

    const columnas = [
        {
            accessorKey: 'nombre',
            header: 'Nombre'
        },
        {
            id: 'linea',
            accessorFn: (s) => nombreLinea(s.id_linea),
            header: 'Línea de investigación'
        },
        {
            id: 'descripcion',
            accessorFn: (s) => s.descripcion || 'Sin descripción',
            header: 'Descripción'
        },
        {
            id: 'estado',
            accessorFn: (s) => s.estado ? 'Activo' : 'Inactivo',
            header: 'Estado'
        },
        {
            id: 'acciones',
            header: 'Acciones',
            enableSorting: false
        }
    ];

    const tabla = createTable({
        features,
        columns: columnas,
        get data() {
            return semilleros;
        }
    });
</script>

<svelte:head>
    <title>Semilleros | Gestión de investigación</title>
</svelte:head>

<Navbar />

<main class="contenedor">
    <div class="encabezado">
        <div>
            <p class="subtitulo">GESTIÓN ACADÉMICA</p>
            <h1>Semilleros de investigación</h1>
            <p class="descripcion">
                Administra los semilleros y sus líneas de investigación.
            </p>
        </div>

        <button class="boton-principal" onclick={() => abrirNuevo()}>
            + Nuevo semillero
        </button>
    </div>

    {#if mensaje}
        <div class="alerta exito">{mensaje}</div>
    {/if}

    {#if error}
        <div class="alerta error">{error}</div>
    {/if}

    {#if cargando}
        <Loading mensaje="Cargando semilleros..." />
    {:else}
        <div class="resumen">
            <span>Total de semilleros registrados</span>
            <strong>{semilleros.length}</strong>
        </div>

        {#if semilleros.length === 0}
            <div class="vacio">
                <h3>Aún no hay semilleros</h3>
                <p>Puedes registrar el primero con el botón de arriba.</p>
            </div>
        {:else}
            <div class="tabla-contenedor">
                <table>
                    <thead>
                        {#each tabla.getHeaderGroups() as grupo (grupo.id)}
                            <tr>
                                {#each grupo.headers as encabezado (encabezado.id)}
                                    <th>
                                        {#if !encabezado.isPlaceholder}
                                            {#if encabezado.column.getCanSort()}
                                                <button
                                                    class="boton-orden"
                                                    onclick={encabezado.column.getToggleSortingHandler()}
                                                >
                                                    <FlexRender header={encabezado} />
                                                    {#if encabezado.column.getIsSorted() === 'asc'}
                                                        ↑
                                                    {:else if encabezado.column.getIsSorted() === 'desc'}
                                                        ↓
                                                    {/if}
                                                </button>
                                            {:else}
                                                <FlexRender header={encabezado} />
                                            {/if}
                                        {/if}
                                    </th>
                                {/each}
                            </tr>
                        {/each}
                    </thead>

                    <tbody>
                        {#each tabla.getRowModel().rows as fila (fila.id)}
                            <tr>
                                {#each fila.getAllCells() as celda (celda.id)}
                                    <td>
                                        {#if celda.column.id === 'acciones'}
                                            <div class="acciones">
                                                <button
                                                    class="boton-editar"
                                                    onclick={() => abrirEdicion(fila.original)}
                                                >
                                                    Editar
                                                </button>

                                                <button
                                                    class="boton-eliminar"
                                                    onclick={() => solicitarEliminar(fila.original)}
                                                >
                                                    Eliminar
                                                </button>
                                            </div>
                                        {:else if celda.column.id === 'estado'}
                                            <span
                                                class:activo={fila.original.estado}
                                                class:inactivo={!fila.original.estado}
                                                class="estado"
                                            >
                                                {fila.original.estado ? 'Activo' : 'Inactivo'}
                                            </span>
                                        {:else}
                                            <FlexRender cell={celda} />
                                        {/if}
                                    </td>
                                {/each}
                            </tr>
                        {/each}
                    </tbody>
                </table>
            </div>
        {/if}
    {/if}

    {#if mostrarFormulario}
        <div class="fondo-modal">
            <section
                class="modal"
                role="dialog"
                aria-modal="true"
                aria-labelledby="titulo-formulario"
            >
                <h2 id="titulo-formulario">
                    {editandoId !== null ? 'Editar semillero' : 'Nuevo semillero'}
                </h2>

                <form onsubmit={(e) => { e.preventDefault(); guardar(); }}>
                    <FormField
                        id="nombre"
                        etiqueta="Nombre del semillero"
                        bind:valor={formulario.nombre}
                        requerido={true}
                        placeholder="Escribe el nombre del semillero"
                        maximoCaracteres={150}
                    />

                    <label for="linea">Línea de investigación</label>
                    <select id="linea" bind:value={formulario.id_linea} required>
                        {#each lineas as linea}
                            <option value={String(linea.id_linea)}>
                                {linea.nombre ??
                                    linea.nombre_linea ??
                                    linea.nombre_linea_investigacion ??
                                    'Línea de investigación'}
                            </option>
                        {/each}
                    </select>

                    <label for="descripcion">Descripción</label>
                    <textarea
                        id="descripcion"
                        bind:value={formulario.descripcion}
                        rows="3"
                    ></textarea>

                    <label class="check">
                        <input type="checkbox" bind:checked={formulario.estado} />
                        Semillero activo
                    </label>

                    <div class="botones-formulario">
                        <button
                            type="button"
                            class="boton-cancelar"
                            onclick={() => mostrarFormulario = false}
                        >
                            Cancelar
                        </button>

                        <button
                            type="submit"
                            class="boton-principal"
                            disabled={guardando || lineas.length === 0}
                        >
                            {guardando ? 'Guardando...' : 'Guardar'}
                        </button>
                    </div>

                    {#if lineas.length === 0}
                        <p class="aviso">
                            No hay líneas de investigación disponibles. Registra una primero.
                        </p>
                    {/if}
                </form>
            </section>
        </div>
    {/if}

    <Confirmation
        bind:mostrar={mostrarConfirmacion}
        titulo="Eliminar semillero"
        mensaje={semilleroSeleccionado
            ? `¿Seguro que deseas eliminar "${semilleroSeleccionado.nombre}"?`
            : '¿Seguro que deseas continuar?'}
        textoBoton="Eliminar"
        onConfirmar={eliminarConfirmado}
    />
</main>

<style>
    .boton-orden {
        border: none;
        background: transparent;
        color: inherit;
        font: inherit;
        font-weight: bold;
        text-transform: inherit;
        cursor: pointer;
    }

    :global(body) {
        margin: 0;
        background: #f5f7fb;
        color: #243247;
        font-family: Arial, sans-serif;
    }

    .contenedor {
        max-width: 1250px;
        margin: 0 auto;
        padding: 36px 24px;
    }

    .encabezado {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 20px;
        margin-bottom: 28px;
    }

    h1 {
        margin: 5px 0 10px;
        color: #0f3460;
        font-size: clamp(24px, 3vw, 34px);
    }

    .subtitulo {
        color: #4975a6;
        font-size: 12px;
        font-weight: bold;
        letter-spacing: 1.5px;
    }

    .descripcion {
        color: #66758a;
    }

    .boton-principal,
    .boton-editar,
    .boton-eliminar,
    .boton-cancelar {
        border: 0;
        border-radius: 8px;
        padding: 11px 15px;
        cursor: pointer;
        font-weight: 600;
    }

    .boton-principal {
        background: #0f3460;
        color: white;
    }

    .boton-principal:disabled {
        opacity: .6;
        cursor: not-allowed;
    }

    .boton-editar {
        background: #e5eef9;
        color: #174b83;
    }

    .boton-eliminar {
        background: #fff0f0;
        color: #b42323;
    }

    .boton-cancelar {
        background: #e9edf2;
        color: #344054;
    }

    .resumen,
    .tabla-contenedor,
    .vacio {
        background: white;
        border: 1px solid #e6eaf0;
        border-radius: 12px;
        box-shadow: 0 4px 16px #162c4a08;
    }

    .resumen {
        padding: 18px 22px;
        margin-bottom: 18px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        color: #526176;
    }

    .resumen strong {
        color: #0f3460;
        font-size: 26px;
    }

    .tabla-contenedor {
        overflow-x: auto;
    }

    table {
        width: 100%;
        border-collapse: collapse;
    }

    th,
    td {
        text-align: left;
        padding: 16px;
        border-bottom: 1px solid #edf0f4;
        font-size: 14px;
    }

    th {
        background: #f9fafc;
        color: #526176;
        font-size: 12px;
        text-transform: uppercase;
    }

    tr:last-child td {
        border-bottom: 0;
    }

    .nombre {
        color: #0f3460;
        font-weight: 600;
    }

    .estado {
        display: inline-block;
        border-radius: 20px;
        padding: 5px 10px;
        font-size: 12px;
        font-weight: bold;
    }

    .activo {
        background: #e4f7ec;
        color: #187647;
    }

    .inactivo {
        background: #f1f2f4;
        color: #596579;
    }

    .acciones {
        display: flex;
        gap: 8px;
    }

    .alerta {
        padding: 12px 16px;
        border-radius: 8px;
        margin-bottom: 16px;
    }

    .exito {
        background: #e4f7ec;
        color: #187647;
    }

    .error {
        background: #fff0f0;
        color: #b42323;
    }

    .estado-pagina {
        padding: 30px 0;
        color: #66758a;
    }

    .vacio {
        text-align: center;
        padding: 40px 20px;
    }

    .vacio h3 {
        color: #0f3460;
    }

    .vacio p {
        color: #66758a;
    }

    .fondo-modal {
        position: fixed;
        inset: 0;
        z-index: 1000;
        display: grid;
        place-items: center;
        padding: 16px;
        background: #10233c88;
        overflow-y: auto;
    }

    .modal {
        position: relative;
        display: block !important;
        z-index: 1001;
        width: 100%;
        max-width: 520px;
        box-sizing: border-box;
        max-height: 95vh;
        overflow-y: auto;
        background: #ffffff;
        color: #10233c;
        border-radius: 14px;
        padding: 26px;
        box-shadow: 0 10px 35px #00000040;
    }

    .modal h2 {
        color: #0f3460;
        margin-top: 0;
    }

    .modal form > label:not(.check) {
        display: block;
        margin: 16px 0 7px;
        font-size: 14px;
        font-weight: 600;
    }

    .modal input:not([type="checkbox"]),
    .modal select,
    .modal textarea {
        width: 100%;
        box-sizing: border-box;
        padding: 11px;
        border: 1px solid #d5dce6;
        border-radius: 7px;
        font: inherit;
    }

    .check {
        display: flex;
        gap: 9px;
        align-items: center;
        margin-top: 16px;
    }

    .botones-formulario {
        display: flex;
        justify-content: flex-end;
        gap: 10px;
        margin-top: 24px;
    }

    .aviso {
        color: #a15c00;
        font-size: 13px;
    }

    @media (max-width: 650px) {
        .contenedor {
            padding: 24px 14px;
        }

        .encabezado {
            align-items: flex-start;
            flex-direction: column;
        }

        .acciones {
            flex-direction: column;
        }
    }
</style>
