
<script>
    let {
        mostrar = $bindable(false),
        titulo = 'Confirmar acción',
        mensaje = '¿Estás segura de que deseas continuar?',
        textoBoton = 'Confirmar',
        onConfirmar
    } = $props();

    let procesando = $state(false);

    function cancelar() {
        if (procesando) return;
        mostrar = false;
    }

    async function confirmar() {
        if (procesando) return;

        procesando = true;

        try {
            if (onConfirmar) {
                await onConfirmar();
            }

            mostrar = false;
        } catch (error) {
            console.error('No se pudo completar la acción:', error);
        } finally {
            procesando = false;
        }
    }
</script>

{#if mostrar}
    <div
        class="fondo-modal"
        onclick={(evento) => {
            if (evento.target === evento.currentTarget) {
                cancelar();
            }
        }}
        onkeydown={(evento) => {
            if (evento.key === 'Escape') cancelar();
        }}
    >
        <section
            class="modal-card card border-0 shadow-lg"
            role="alertdialog"
            aria-modal="true"
            aria-labelledby="titulo-confirmacion"
            aria-describedby="mensaje-confirmacion"
        >
            <div class="card-body p-4 p-sm-5 text-center">
                <div class="icono-alerta mx-auto mb-3">
                    <i class="bi bi-exclamation-triangle"></i>
                </div>

                <h2
                    id="titulo-confirmacion"
                    class="h5 fw-bold mb-2"
                >
                    {titulo}
                </h2>

                <p
                    id="mensaje-confirmacion"
                    class="text-secondary mb-4"
                >
                    {mensaje}
                </p>

                <div class="d-flex flex-column flex-sm-row justify-content-center gap-2">
                    <button
                        type="button"
                        class="btn btn-light border px-4"
                        onclick={cancelar}
                        disabled={procesando}
                    >
                        Cancelar
                    </button>

                    <button
                        type="button"
                        class="btn btn-danger px-4"
                        onclick={confirmar}
                        disabled={procesando}
                    >
                        {#if procesando}
                            <span
                                class="spinner-border spinner-border-sm me-2"
                                aria-hidden="true"
                            ></span>
                            Procesando...
                        {:else}
                            {textoBoton}
                        {/if}
                    </button>
                </div>
            </div>
        </section>
    </div>
{/if}

<style>
    .fondo-modal {
        position: fixed;
        inset: 0;
        z-index: 2000;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 20px;
        background: rgba(15, 30, 50, 0.48);
        backdrop-filter: blur(3px);
        animation: aparecer 0.18s ease-out;
    }

    .modal-card {
        width: 100%;
        max-width: 400px;
        border-radius: 16px;
        animation: subir 0.2s ease-out;
    }

    .icono-alerta {
        width: 54px;
        height: 54px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
        background: #fff3cd;
        color: #a66b00;
        font-size: 25px;
    }

    #titulo-confirmacion {
        color: #0f3460;
    }

    #mensaje-confirmacion {
        line-height: 1.6;
    }

    @keyframes aparecer {
        from { opacity: 0; }
        to { opacity: 1; }
    }

    @keyframes subir {
        from {
            opacity: 0;
            transform: translateY(8px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    @media (prefers-reduced-motion: reduce) {
        .fondo-modal,
        .modal-card {
            animation: none;
        }
    }
</style>
