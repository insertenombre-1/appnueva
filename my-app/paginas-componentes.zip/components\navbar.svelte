
<script>
    import logo from '$lib/assets/cul.png';
    import { page } from '$app/state';

    let {
    nombreUsuario = 'Usuario',
    rolUsuario = '',
    modulosPermitidos = [
        'inicio',
        'eventos',
        'estudiantes',
        'semilleros',
        'proyectos',
        'productos'
    ]
    } = $props();

    let menuAbierto = $state(false);
    let usuarioMenuAbierto = $state(false);

    const modulos = [
        {
            id: 'inicio',
            nombre: 'Inicio',
            ruta: '/inicio',
            icono: 'bi-house-door'
        },
        {
            id: 'eventos',
            nombre: 'Eventos',
            ruta: '/eventos',
            icono: 'bi-calendar-event'
        },
        {
            id: 'estudiantes',
            nombre: 'Estudiantes',
            ruta: '/Estudiantes',
            icono: 'bi-people'
        },
        {
            id: 'semilleros',
            nombre: 'Semilleros',
            ruta: '/semilleros',
            icono: 'bi-mortarboard'
        },
        {
            id: 'proyectos',
            nombre: 'Proyectos',
            ruta: '/proyectos',
            icono: 'bi-folder2-open'
        },
        {
            id: 'productos',
            nombre: 'Productos',
            ruta: '/productos',
            icono: 'bi-file-earmark-text'
        }
    ];

    let modulosVisibles = $derived(
        modulos.filter((modulo) =>
            modulosPermitidos.includes(modulo.id)
        )
    );

    function cerrarMenus() {
        menuAbierto = false;
        usuarioMenuAbierto = false;
    }

    function cerrarSesion() {
        cerrarMenus();
        window.location.href = '/';
    }
</script>

<svelte:head>
    <title>Gestión de Semilleros | CUL</title>
</svelte:head>

<nav class="navbar navbar-expand-lg bg-white border-bottom shadow-sm sticky-top">
    <div class="container-fluid px-4">
        <a
            class="navbar-brand d-flex align-items-center gap-3"
            href="/inicio"
            onclick={cerrarMenus}
        >
            <img
                src={logo}
                alt="Logo CUL"
                width="48"
                height="48"
                style="object-fit: contain;"
            />

            <div class="d-none d-sm-block">
                <div class="fw-bold titulo-navbar">
                    Gestión de Semilleros
                </div>
                <small class="text-secondary">CUL</small>
            </div>
        </a>

        <button
            class="navbar-toggler"
            type="button"
            aria-controls="navbarPrincipal"
            aria-expanded={menuAbierto}
            aria-label="Mostrar navegación"
            onclick={() => menuAbierto = !menuAbierto}
        >
            <span class="navbar-toggler-icon"></span>
        </button>

        <div
            id="navbarPrincipal"
            class:show={menuAbierto}
            class="collapse navbar-collapse"
        >
            <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
                {#each modulosVisibles as modulo (modulo.id)}
                    <li class="nav-item">
                        <a
                            class="nav-link"
                            class:activo={page.url.pathname === modulo.ruta}
                            href={modulo.ruta}
                            aria-current={page.url.pathname === modulo.ruta ? 'page' : undefined}
                            onclick={cerrarMenus}
                        >
                            <i class={`bi ${modulo.icono} me-1`}></i>
                            {modulo.nombre}
                        </a>
                    </li>
                {/each}
            </ul>

            <div class="dropdown">
                <button
                    class="btn usuario-btn dropdown-toggle d-flex align-items-center gap-2"
                    type="button"
                    aria-expanded={usuarioMenuAbierto}
                    onclick={() => usuarioMenuAbierto = !usuarioMenuAbierto}
                >
                    <span class="usuario-icono">
                        <i class="bi bi-person-fill"></i>
                    </span>

                    <span class="usuario-texto">
                        <span class="fw-semibold">{nombreUsuario}</span>

                        {#if rolUsuario}
                            <small class="d-block text-secondary">
                                {rolUsuario}
                            </small>
                        {/if}
                    </span>
                </button>

                {#if usuarioMenuAbierto}
                    <ul class="dropdown-menu dropdown-menu-end shadow show">
                        <li>
                            <a
                                class="dropdown-item"
                                href="/perfil"
                                onclick={cerrarMenus}
                            >
                                <i class="bi bi-person me-2"></i>
                                Mi perfil
                            </a>
                        </li>

                        <li>
                            <a
                                class="dropdown-item"
                                href="/configuracion"
                                onclick={cerrarMenus}
                            >
                                <i class="bi bi-gear me-2"></i>
                                Configuración
                            </a>
                        </li>

                        <li><hr class="dropdown-divider" /></li>

                        <li>
                            <button
                                class="dropdown-item text-danger"
                                type="button"
                                onclick={cerrarSesion}
                            >
                                <i class="bi bi-box-arrow-right me-2"></i>
                                Cerrar sesión
                            </button>
                        </li>
                    </ul>
                {/if}
            </div>
        </div>
    </div>
</nav>

<style>
    .titulo-navbar {
        color: #0f3460;
        font-size: 1.15rem;
    }

    .nav-link {
        color: #5f6873;
        font-weight: 500;
        padding: 10px 14px !important;
        transition: color 0.2s, background-color 0.2s;
        border-radius: 7px;
    }

    .nav-link:hover,
    .nav-link.activo {
        color: #0f3460;
        background-color: #edf4fc;
    }

    .usuario-btn {
        border: none;
        background: transparent;
        border-radius: 8px;
        padding: 6px 10px;
    }

    .usuario-btn:hover {
        background-color: #f1f5f9;
    }

    .usuario-icono {
        width: 40px;
        height: 40px;
        flex-shrink: 0;
        border-radius: 50%;
        background-color: #0f3460;
        color: white;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.1rem;
    }

    .usuario-texto {
        text-align: left;
        overflow-wrap: anywhere;
    }

    .dropdown {
        position: relative;
    }

    .dropdown-menu {
        border: none;
        border-radius: 12px;
        min-width: 190px;
        margin-top: 8px;
    }

    .dropdown-item {
        padding: 10px 15px;
    }

    @media (max-width: 991px) {
        .navbar-collapse {
            padding: 12px 0;
        }

        .navbar-nav {
            align-items: stretch;
        }

        .usuario-btn {
            margin-top: 8px;
        }

        .dropdown-menu {
            position: static;
            float: none;
            width: 100%;
        }
    }
</style>
