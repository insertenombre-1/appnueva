
<script>
    let {
        id,
        etiqueta,
        tipo = 'text',
        valor = $bindable(''),
        requerido = false,
        placeholder = '',
        maximoCaracteres
    } = $props();
</script>

<div class="campo">
    <label for={id}>{etiqueta}</label>

    <input
        id={id}
        type={tipo}
        bind:value={valor}
        required={requerido}
        placeholder={placeholder}
        maxlength={maximoCaracteres}
    />
</div>

<style>
    .campo {
        display: flex;
        flex-direction: column;
        gap: 7px;
        margin-top: 16px;
    }

    label {
        font-size: 14px;
        font-weight: 600;
        color: #344054;
    }

    input {
        width: 100%;
        box-sizing: border-box;
        padding: 11px;
        border: 1px solid #d5dce6;
        border-radius: 7px;
        font: inherit;
    }

    input:focus {
        outline: 2px solid #b8d4f5;
        border-color: #4975a6;
    }
</style>
